name: peroxide
flag: ODYSSEY{th3_fl4g_1s_r41s3d}
desc: at the bus stop, crushing rocks